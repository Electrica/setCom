--------------------
setCom
--------------------
Author: Electrica <info@modx.kz>
--------------------
