<?php

$_lang['area_setcom_main'] = 'Main';

$_lang['setting_setcom_some_setting'] = 'Some setting';
$_lang['setting_setcom_some_setting_desc'] = 'This is description for some setting';