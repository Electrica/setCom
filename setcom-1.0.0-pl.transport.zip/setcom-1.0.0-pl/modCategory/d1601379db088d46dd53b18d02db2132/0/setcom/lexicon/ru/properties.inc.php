<?php

$_lang['setcom_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['setcom_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['setcom_prop_sortby'] = 'Поле сортировки.';
$_lang['setcom_prop_sortdir'] = 'Направление сортировки.';
$_lang['setcom_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['setcom_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
