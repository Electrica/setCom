<?php

/**
 * @package setcom
 */
class setComItem extends xPDOSimpleObject
{
}